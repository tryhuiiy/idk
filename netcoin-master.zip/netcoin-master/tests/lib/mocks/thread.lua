local thread= {}

thread.create = function(callback)

end

return thread