local shell = {}

shell.getWorkingDirectory = function () return '/home' end

return shell