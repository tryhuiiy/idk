local serialization = {}

function serialization.serialize(object)
    return ""
end

return serialization